#!/bin/bash
APP_DIR="/Users/ritchegerona/Documents/PROJECTS/task-tracker"
APP_NAME="Chie-Task_Tracker.app"

echo "🔧 Fixing persistence & setting up Chie-Task_Tracker server..."

# 1. Update HTML with robust persistence + title fix
cat > "$APP_DIR/task_tracker.html" << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chie-Task_Tracker</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 950px; margin: 40px auto; padding: 20px; background: #faf9f7; min-height: 100vh; color: #5a5a5a; }
        .container { background: white; border-radius: 16px; padding: 30px; box-shadow: 0 2px 20px rgba(0,0,0,0.04); }
        h1 { color: #6b5e54; margin-bottom: 25px; font-size: 26px; font-weight: 600; }
        .dashboard { display: grid; grid-template-columns: 1.8fr 1.2fr; gap: 20px; margin-bottom: 25px; }
        .left-col, .right-col { display: flex; flex-direction: column; gap: 15px; }
        .stats { display: flex; gap: 12px; }
        .stat-box { flex: 1; background: #f8f6f4; padding: 15px; border-radius: 10px; text-align: center; border: 1px solid #f0ede9; }
        .stat-number { font-size: 22px; font-weight: 700; color: #7bcba3; }
        .stat-label { font-size: 10px; color: #9a9a9a; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
        .overall-progress { height: 6px; background: #f0ede9; border-radius: 3px; overflow: hidden; margin-top: 12px; }
        .overall-progress-fill { height: 100%; background: #7bcba3; transition: width 0.3s ease; }
        .deadlines-card { background: #f8f6f4; border: 1px solid #f0ede9; border-radius: 10px; padding: 18px; flex: 1; }
        .card-title { font-size: 14px; font-weight: 700; color: #6b5e54; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
        .deadline-item { display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; background: white; border-radius: 8px; margin-bottom: 8px; border-left: 3px solid #e0e0e0; font-size: 13px; }
        .deadline-item.overdue { border-left-color: #e895a8; background: #fffafa; }
        .deadline-item.today { border-left-color: #f4d4a7; background: #fffcf5; }
        .deadline-item.tomorrow { border-left-color: #7bcba3; }
        .deadline-meta { font-size: 11px; color: #9a9a9a; margin-top: 2px; }
        .snooze-btn { background: none; border: 1px solid #e8e5e1; color: #7c6f64; font-size: 10px; padding: 3px 8px; border-radius: 4px; cursor: pointer; margin-left: 4px; }
        .snooze-btn:hover { background: #7bcba3; color: white; border-color: #7bcba3; }
        .no-deadlines { color: #c0c0c0; font-style: italic; text-align: center; padding: 20px; font-size: 13px; }
        .calendar-widget, .summary-widget { background: #f8f6f4; padding: 15px; border-radius: 10px; border: 1px solid #f0ede9; }
        .calendar-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .calendar-title { font-size: 13px; font-weight: 700; color: #6b5e54; }
        .calendar-nav { background: none; border: none; color: #7bcba3; cursor: pointer; font-size: 16px; padding: 2px 6px; }
        .calendar-nav:hover { background: #e8f5e9; border-radius: 4px; }
        .calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 3px; text-align: center; }
        .calendar-day-header { font-size: 9px; color: #9a9a9a; padding: 4px; font-weight: 600; }
        .calendar-day { font-size: 11px; padding: 5px; border-radius: 6px; cursor: pointer; position: relative; }
        .calendar-day:hover { background: #e8f5e9; }
        .calendar-day.today { background: #7bcba3; color: white; font-weight: 700; }
        .calendar-day.has-tasks::after { content:''; position:absolute; bottom:2px; left:50%; transform:translateX(-50%); width:4px; height:4px; background:#f4a7b9; border-radius:50%; }
        .calendar-day.other-month { color: #d0d0d0; }
        .summary-title { font-size: 12px; font-weight: 700; color: #6b5e54; margin-bottom: 8px; }
        .summary-item { display: flex; justify-content: space-between; padding: 5px 0; font-size: 11px; border-bottom: 1px solid #f0ede9; }
        .summary-item:last-child { border-bottom: none; }
        .summary-label { color: #9a9a9a; } .summary-value { color: #5a5a5a; font-weight: 700; }
        .input-section { display: flex; gap: 10px; margin-bottom: 25px; }
        input[type="text"] { flex: 1; padding: 12px 15px; border: 1.5px solid #e8e5e1; border-radius: 10px; font-size: 14px; background: #faf9f7; }
        input[type="text"]:focus { outline: none; border-color: #7bcba3; background: white; }
        input[type="date"] { padding: 10px 12px; border: 1.5px solid #e8e5e1; border-radius: 10px; font-size: 13px; background: #faf9f7; color: #5a5a5a; font-family: inherit; }
        input[type="date"]:focus { outline: none; border-color: #7bcba3; background: white; }
        button { padding: 12px 24px; background: #7bcba3; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; transition: all 0.2s; }
        button:hover { background: #6ab892; transform: translateY(-1px); box-shadow: 0 2px 8px rgba(123,203,163,0.3); }
        .section { margin-bottom: 25px; }
        h2 { color: #6b5e54; margin-bottom: 12px; font-size: 15px; font-weight: 700; }
        .task-list { background: #faf9f7; padding: 5px; border-radius: 10px; }
        .task-item { display: flex; flex-direction: column; padding: 14px; background: white; margin-bottom: 8px; border-radius: 8px; border: 1px solid #f0ede9; transition: all 0.2s; }
        .task-item:hover { box-shadow: 0 2px 12px rgba(0,0,0,0.04); border-color: #7bcba3; }
        .task-header { display: flex; align-items: center; margin-bottom: 8px; }
        .task-item input[type="checkbox"] { width: 18px; height: 18px; margin-right: 12px; cursor: pointer; accent-color: #7bcba3; }
        .task-text { flex: 1; font-size: 14px; color: #5a5a5a; font-weight: 500; }
        .completed .task-text { text-decoration: line-through; color: #c0c0c0; }
        .progress-container { display: flex; align-items: center; gap: 10px; margin-top: 6px; }
        .progress-bar-task { flex: 1; height: 6px; background: #f0ede9; border-radius: 3px; overflow: hidden; }
        .progress-fill-task { height: 100%; border-radius: 3px; transition: width 0.3s ease; }
        .progress-text { font-size: 11px; color: #9a9a9a; font-weight: 700; min-width: 35px; text-align: right; }
        .controls { display: flex; align-items: center; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
        .progress-btn { padding: 4px 10px; font-size: 10px; background: #f8f6f4; color: #7c6f64; border: 1px solid #e8e5e1; border-radius: 6px; cursor: pointer; }
        .progress-btn:hover { background: #7bcba3; color: white; border-color: #7bcba3; }
        .delete-btn { background: #f4a7b9; padding: 6px 12px; font-size: 10px; margin-left: auto; border-radius: 6px; border: none; color: white; cursor: pointer; }
        .delete-btn:hover { background: #e895a8; }
        .date-tag { font-size: 10px; color: #9a9a9a; margin-left: 10px; background: #f8f6f4; padding: 3px 8px; border-radius: 6px; }
        .empty { color: #c0c0c0; text-align: center; padding: 25px; font-style: italic; font-size: 13px; }
        .save-indicator { position: fixed; bottom: 20px; right: 20px; background: #7bcba3; color: white; padding: 8px 16px; border-radius: 20px; font-size: 12px; opacity: 0; transition: opacity 0.3s; pointer-events: none; }
        .save-indicator.show { opacity: 1; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📋 Chie-Task_Tracker</h1>
        <div class="dashboard">
            <div class="left-col">
                <div>
                    <div class="stats">
                        <div class="stat-box"><div class="stat-number" id="totalTasks">0</div><div class="stat-label">Total</div></div>
                        <div class="stat-box"><div class="stat-number" id="pendingTasks">0</div><div class="stat-label">Pending</div></div>
                        <div class="stat-box"><div class="stat-number" id="completedTasks">0</div><div class="stat-label">Done</div></div>
                    </div>
                    <div class="overall-progress"><div class="overall-progress-fill" id="progressBar" style="width:0%"></div></div>
                </div>
                <div class="deadlines-card">
                    <div class="card-title">🔔 Upcoming Deadlines</div>
                    <div id="deadlinesList"></div>
                </div>
            </div>
            <div class="right-col">
                <div class="calendar-widget">
                    <div class="calendar-header">
                        <button class="calendar-nav" onclick="changeMonth(-1)">‹</button>
                        <div class="calendar-title" id="calendarTitle"></div>
                        <button class="calendar-nav" onclick="changeMonth(1)">›</button>
                    </div>
                    <div class="calendar-grid" id="calendarGrid"></div>
                </div>
                <div class="summary-widget">
                    <div class="summary-title">📊 Summary</div>
                    <div class="summary-item"><span class="summary-label">Completion Rate</span><span class="summary-value" id="completionRate">0%</span></div>
                    <div class="summary-item"><span class="summary-label">Avg Progress</span><span class="summary-value" id="avgProgress">0%</span></div>
                    <div class="summary-item"><span class="summary-label">This Week</span><span class="summary-value" id="weekTasks">0</span></div>
                </div>
            </div>
        </div>
        <div class="input-section">
            <input type="text" id="taskInput" placeholder="What needs to be done?">
            <input type="date" id="dueDateInput" title="Optional due date">
            <button onclick="addTask()">Add Task</button>
        </div>
        <div class="section"><h2>⏳ Pending</h2><div id="pendingList" class="task-list"></div></div>
        <div class="section"><h2>✅ Completed</h2><div id="completedList" class="task-list"></div></div>
    </div>
    <div id="saveIndicator" class="save-indicator">✓ Saved automatically</div>

    <script>
        // ROBUST PERSISTENCE: Try multiple keys to prevent data loss
        function loadTasks() {
            try {
                return JSON.parse(localStorage.getItem('tasks')) || 
                       JSON.parse(localStorage.getItem('tasks_v3')) || 
                       JSON.parse(localStorage.getItem('chie_tasks')) || [];
            } catch(e) { return []; }
        }
        
        let tasks = loadTasks();
        let currentCalendarDate = new Date();
        
        function saveTasks() { 
            // Save to primary key + backup
            const data = JSON.stringify(tasks);
            localStorage.setItem('chie_tasks', data);
            localStorage.setItem('tasks', data);
            
            // Visual feedback
            const ind = document.getElementById('saveIndicator');
            ind.classList.add('show');
            setTimeout(() => ind.classList.remove('show'), 1500);
            
            render(); 
        }
        
        function addTask() {
            const text = document.getElementById('taskInput').value.trim();
            const due = document.getElementById('dueDateInput').value;
            if (text) {
                tasks.push({ id: Date.now(), text, completed: false, progress: 0, dueDate: due || null, snoozedUntil: null, completedDate: null, createdAt: new Date().toISOString() });
                document.getElementById('taskInput').value = '';
                document.getElementById('dueDateInput').value = '';
                saveTasks();
            }
        }
        
        function toggleTask(id) {
            const t = tasks.find(x => x.id === id);
            if (t) { t.completed = !t.completed; t.progress = t.completed ? 100 : t.progress; t.completedDate = t.completed ? new Date().toLocaleString() : null; saveTasks(); }
        }
        
        function updateProgress(id, val) {
            const t = tasks.find(x => x.id === id);
            if (t && !t.completed) { t.progress = Math.max(0, Math.min(100, val)); if (t.progress === 100) { t.completed = true; t.completedDate = new Date().toLocaleString(); } saveTasks(); }
        }
        
        function deleteTask(id) { tasks = tasks.filter(t => t.id !== id); saveTasks(); }
        
        function snoozeTask(id, hours) {
            const t = tasks.find(x => x.id === id);
            if (t) { t.snoozedUntil = new Date(Date.now() + hours * 3600000).toISOString(); saveTasks(); }
        }
        
        function getProgressColor(p) { return p < 25 ? '#f4a7b9' : p < 50 ? '#f4d4a7' : p < 75 ? '#7bcba3' : '#89c4e8'; }
        
        function changeMonth(d) { currentCalendarDate.setMonth(currentCalendarDate.getMonth() + d); renderCalendar(); }
        
        function renderCalendar() {
            const y = currentCalendarDate.getFullYear(), m = currentCalendarDate.getMonth();
            const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
            document.getElementById('calendarTitle').textContent = `${months[m]} ${y}`;
            const firstDay = new Date(y, m, 1).getDay(), daysInMonth = new Date(y, m+1, 0).getDate(), today = new Date();
            const daysWithTasks = new Set();
            tasks.forEach(t => { const d = new Date(t.createdAt); if (d.getFullYear()===y && d.getMonth()===m) daysWithTasks.add(d.getDate()); });
            let html = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => `<div class="calendar-day-header">${d}</div>`).join('');
            for (let i=0; i<firstDay; i++) html += '<div class="calendar-day other-month"></div>';
            for (let d=1; d<=daysInMonth; d++) {
                const isToday = today.getDate()===d && today.getMonth()===m && today.getFullYear()===y;
                let cls = 'calendar-day'; if (isToday) cls += ' today'; if (daysWithTasks.has(d)) cls += ' has-tasks';
                html += `<div class="${cls}">${d}</div>`;
            }
            document.getElementById('calendarGrid').innerHTML = html;
        }
        
        function renderDeadlines() {
            const now = new Date(); const todayStr = now.toISOString().slice(0,10);
            const tomorrow = new Date(now); tomorrow.setDate(tomorrow.getDate()+1); const tomorrowStr = tomorrow.toISOString().slice(0,10);
            const pending = tasks.filter(t => !t.completed && t.dueDate);
            const visible = pending.filter(t => !t.snoozedUntil || new Date(t.snoozedUntil) <= now);
            if (!visible.length) { document.getElementById('deadlinesList').innerHTML = '<div class="no-deadlines">No upcoming deadlines 🎉</div>'; return; }
            visible.sort((a,b) => a.dueDate.localeCompare(b.dueDate));
            document.getElementById('deadlinesList').innerHTML = visible.slice(0, 6).map(t => {
                let cls = '', label = '';
                if (t.dueDate < todayStr) { cls = 'overdue'; label = 'Overdue'; }
                else if (t.dueDate === todayStr) { cls = 'today'; label = 'Today'; }
                else if (t.dueDate === tomorrowStr) { cls = 'tomorrow'; label = 'Tomorrow'; }
                else { label = t.dueDate; }
                return `<div class="deadline-item ${cls}">
                    <div><strong>${t.text}</strong><div class="deadline-meta">${label} · ${t.progress}%</div></div>
                    <div>
                        <button class="snooze-btn" onclick="snoozeTask(${t.id},1)">1h</button>
                        <button class="snooze-btn" onclick="snoozeTask(${t.id},4)">4h</button>
                        <button class="snooze-btn" onclick="snoozeTask(${t.id},24)">1d</button>
                    </div>
                </div>`;
            }).join('');
        }
        
        function updateStats() {
            const total = tasks.length, completed = tasks.filter(t=>t.completed).length, pending = total-completed;
            const pct = total>0 ? (completed/total)*100 : 0;
            const avg = total>0 ? tasks.reduce((s,t)=>s+t.progress,0)/total : 0;
            const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate()-7);
            const week = tasks.filter(t => new Date(t.createdAt) >= weekAgo).length;
            document.getElementById('totalTasks').textContent = total;
            document.getElementById('pendingTasks').textContent = pending;
            document.getElementById('completedTasks').textContent = completed;
            document.getElementById('progressBar').style.width = pct+'%';
            document.getElementById('completionRate').textContent = Math.round(pct)+'%';
            document.getElementById('avgProgress').textContent = Math.round(avg)+'%';
            document.getElementById('weekTasks').textContent = week;
        }
        
        function render() {
            updateStats(); renderCalendar(); renderDeadlines();
            const pending = tasks.filter(t=>!t.completed), completed = tasks.filter(t=>t.completed);
            document.getElementById('pendingList').innerHTML = pending.length ? pending.map(t => `
                <div class="task-item">
                    <div class="task-header">
                        <input type="checkbox" onchange="toggleTask(${t.id})">
                        <span class="task-text">${t.text}</span>
                        ${t.dueDate ? `<span class="date-tag">📅 ${t.dueDate}</span>` : ''}
                    </div>
                    <div class="progress-container">
                        <div class="progress-bar-task"><div class="progress-fill-task" style="width:${t.progress}%;background:${getProgressColor(t.progress)}"></div></div>
                        <span class="progress-text">${t.progress}%</span>
                    </div>
                    <div class="controls">
                        <button class="progress-btn" onclick="updateProgress(${t.id},${Math.max(0,t.progress-10)})">-10%</button>
                        <button class="progress-btn" onclick="updateProgress(${t.id},${Math.min(100,t.progress+10)})">+10%</button>
                        <button class="progress-btn" onclick="updateProgress(${t.id},25)">25%</button>
                        <button class="progress-btn" onclick="updateProgress(${t.id},50)">50%</button>
                        <button class="progress-btn" onclick="updateProgress(${t.id},75)">75%</button>
                        <button class="delete-btn" onclick="deleteTask(${t.id})">Delete</button>
                    </div>
                </div>`).join('') : '<div class="empty">No pending tasks 🎉</div>';
            document.getElementById('completedList').innerHTML = completed.length ? completed.map(t => `
                <div class="task-item completed">
                    <div class="task-header">
                        <input type="checkbox" checked onchange="toggleTask(${t.id})">
                        <span class="task-text">${t.text}</span>
                        <span class="date-tag">✓ ${t.completedDate}</span>
                    </div>
                    <div class="progress-container">
                        <div class="progress-bar-task"><div class="progress-fill-task" style="width:100%;background:#7bcba3"></div></div>
                        <span class="progress-text">100%</span>
                    </div>
                    <div class="controls"><button class="delete-btn" onclick="deleteTask(${t.id})">Delete</button></div>
                </div>`).join('') : '<div class="empty">No completed tasks yet</div>';
        }
        
        document.getElementById('taskInput').addEventListener('keypress', e => { if(e.key==='Enter') addTask(); });
        
        // Auto-save on page unload as extra safety
        window.addEventListener('beforeunload', () => {
            localStorage.setItem('chie_tasks', JSON.stringify(tasks));
        });
        
        render();
    </script>
</body>
</html>
EOF

# 2. Create Local Server Launcher for clean URL
cat > "$APP_DIR/server.py" << 'PYEOF'
import http.server, socketserver, os, webbrowser, threading, time
PORT = 8765
DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(DIR)
handler = http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(("", PORT), handler) as httpd:
    url = f"http://localhost:{PORT}/task_tracker.html"
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    print(f"✓ Chie-Task_Tracker running at {url}")
    print("  Press Ctrl+C to stop")
    httpd.serve_forever()
PYEOF

# 3. Create .app bundle with server launcher
mkdir -p "$APP_DIR/$APP_NAME/Contents/MacOS"
mkdir -p "$APP_DIR/$APP_NAME/Contents/Resources"

cat > "$APP_DIR/$APP_NAME/Contents/MacOS/launcher" << LAUNCHEOF
#!/bin/bash
cd "$(dirname "$0")/../.."
python3 server.py
LAUNCHEOF
chmod +x "$APP_DIR/$APP_NAME/Contents/MacOS/launcher"

cat > "$APP_DIR/$APP_NAME/Contents/Info.plist" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key><string>launcher</string>
    <key>CFBundleIconFile</key><string>AppIcon</string>
    <key>CFBundleName</key><string>Chie-Task_Tracker</string>
    <key>CFBundleIdentifier</key><string>com.chie.tasktracker</string>
    <key>CFBundleVersion</key><string>4.0</string>
</dict>
</plist>
PLISTEOF

# Reuse existing icon if available
if [ -f "$APP_DIR/TaskTracker.app/Contents/Resources/AppIcon.icns" ]; then
    cp "$APP_DIR/TaskTracker.app/Contents/Resources/AppIcon.icns" "$APP_DIR/$APP_NAME/Contents/Resources/AppIcon.icns"
    echo "✓ Mint icon applied"
fi

echo ""
echo "✅ Chie-Task_Tracker v4 installed!"
echo "🔒 Persistence: Triple-key backup + auto-save on exit"
echo "🌐 URL: http://localhost:8765/task_tracker.html"
echo "📍 App: $APP_DIR/$APP_NAME"
echo ""
echo "→ Drag '$APP_NAME' to your Dock!"
echo "→ Old tasks will be recovered automatically"
