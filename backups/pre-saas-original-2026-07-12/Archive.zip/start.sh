#!/bin/bash
cd /Users/ritchegerona/Documents/PROJECTS/task-tracker
python3 server.py &
sleep 1
open "http://localhost:8765/task_tracker.html"
echo "✓ Chie-Task_Tracker is running!"
echo "💾 Data: storage/tasks.json"
echo "  Press Ctrl+C to stop"
wait
