#!/bin/bash
APP_DIR="/Users/ritchegerona/Documents/PROJECTS/task-tracker"

echo "🔧 Patching v5.2: New Categories + Edit in Completed/Work Log..."

python3 << 'PYEOF'
path = "/Users/ritchegerona/Documents/PROJECTS/task-tracker/task_tracker.html"
with open(path, 'r') as f:
    html = f.read()

# 1. Add new categories to ALL select dropdowns (input, edit modal)
new_cats = """                    <option value="Candidates">Candidates</option>
                    <option value="Recruitment">Recruitment</option>
                    <option value="Documentation">Documentation</option>
                    <option value="Dataflow">Dataflow</option>
                    <option value="Mumaris+">Mumaris+</option>
                    <option value="IT">IT</option>"""

# Add to main input dropdown
html = html.replace(
    '<option value="Follow-up">Follow-up</option>\n                </select>',
    '<option value="Follow-up">Follow-up</option>\n' + new_cats + '\n                </select>',
    1  # Only first occurrence (main input)
)

# Add to edit modal dropdown
html = html.replace(
    '<option value="Follow-up">Follow-up</option>\n                </select>\n            </div>\n            <div class="edit-field"><label>Priority</label>',
    '<option value="Follow-up">Follow-up</option>\n' + new_cats + '\n                </select>\n            </div>\n            <div class="edit-field"><label>Priority</label>'
)

# 2. Add sidebar filter buttons for new categories
new_filters = """                <button class="filter-btn" onclick="setFilter('Candidates')"><div class="filter-dot" style="background:#a7d8f4"></div>Candidates</button>
                <button class="filter-btn" onclick="setFilter('Recruitment')"><div class="filter-dot" style="background:#f4a7d8"></div>Recruitment</button>
                <button class="filter-btn" onclick="setFilter('Documentation')"><div class="filter-dot" style="background:#d8f4a7"></div>Documentation</button>
                <button class="filter-btn" onclick="setFilter('Dataflow')"><div class="filter-dot" style="background:#a7f4d8"></div>Dataflow</button>
                <button class="filter-btn" onclick="setFilter('Mumaris+')"><div class="filter-dot" style="background:#f4d4a7"></div>Mumaris+</button>
                <button class="filter-btn" onclick="setFilter('IT')"><div class="filter-dot" style="background:#b9b9e8"></div>IT</button>"""

html = html.replace(
    "<button class=\"filter-btn\" onclick=\"setFilter('Follow-up')\"><div class=\"filter-dot\" style=\"background:#d4a7f4\"></div>Follow-up</button>",
    "<button class=\"filter-btn\" onclick=\"setFilter('Follow-up')\"><div class=\"filter-dot\" style=\"background:#d4a7f4\"></div>Follow-up</button>\n" + new_filters
)

# 3. Add edit button to completed task cards
old_completed_actions = """                    <div class="controls"><button class="delete-btn" onclick="deleteTask(${t.id})">Delete</button></div>"""
new_completed_actions = """                    <div class="controls">
                        <button class="edit-btn" onclick="openEdit(${t.id})" title="Edit">✏️</button>
                        <button class="delete-btn" onclick="deleteTask(${t.id})">Delete</button>
                    </div>"""
html = html.replace(old_completed_actions, new_completed_actions)

# 4. Add edit button to Today's Work Log items
old_worklog = """<div class="work-log-item">
                    <span>${t.text}</span>
                    <span class="wl-time">${formatTime(t.timeSpent||0)}</span>
                </div>"""
new_worklog = """<div class="work-log-item">
                    <span>${t.text}</span>
                    <div style="display:flex;align-items:center;gap:6px;">
                        <span class="wl-time">${formatTime(t.timeSpent||0)}</span>
                        <button class="edit-btn" onclick="openEdit(${t.id})" title="Edit" style="width:22px;height:22px;font-size:11px;">✏️</button>
                    </div>
                </div>"""
html = html.replace(old_worklog, new_worklog)

with open(path, 'w') as f:
    f.write(html)

print("✓ v5.2 patched successfully")
PYEOF

echo ""
echo "✅ Chie-Task_Tracker v5.2 installed!"
echo "📂 New Categories: Candidates, Recruitment, Documentation, Dataflow, Mumaris+, IT"
echo "✏️  Edit button added to: Completed Tasks + Today's Work Log"
echo "🎨 Sidebar filters updated with new category colors"
echo ""
echo "→ Refresh browser or relaunch from Dock!"
