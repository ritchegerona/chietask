#!/bin/bash
APP_DIR="/Users/ritchegerona/Documents/PROJECTS/task-tracker"

echo "💾 Upgrading to v5.3: File-Based Storage..."

# 1. Create JSON storage server (replaces simple http.server)
cat > "$APP_DIR/server.py" << 'PYEOF'
import http.server, socketserver, os, webbrowser, threading, json, urllib.parse

PORT = 8765
DIR = os.path.dirname(os.path.abspath(__file__))
TASKS_FILE = os.path.join(DIR, "tasks.json")
os.chdir(DIR)

def load_tasks():
    try:
        with open(TASKS_FILE, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_tasks(data):
    with open(TASKS_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/tasks":
            tasks = load_tasks()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(tasks).encode())
            return
        super().do_GET()

    def do_POST(self):
        if self.path == "/api/tasks":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            try:
                data = json.loads(body)
                save_tasks(data)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"ok":true}')
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode())
            return
        self.send_response(404)
        self.end_headers()

    def log_message(self, format, *args):
        pass  # Silent logs

# Migrate old localStorage tasks on first run
if not os.path.exists(TASKS_FILE):
    save_tasks([])
    print("✓ Created tasks.json")

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    url = f"http://localhost:{PORT}/task_tracker.html"
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    print(f"✓ Chie-Task_Tracker v5.3 running at {url}")
    print(f"💾 Storage: {TASKS_FILE}")
    print("  Press Ctrl+C to stop")
    httpd.serve_forever()
PYEOF

# 2. Update HTML to use file-based API instead of localStorage
python3 << 'PYEOF'
path = "/Users/ritchegerona/Documents/PROJECTS/task-tracker/task_tracker.html"
with open(path, "r") as f:
    html = f.read()

# Replace loadTasks function
old_load = """        function loadTasks() {
            try { return JSON.parse(localStorage.getItem('chie_tasks')) || JSON.parse(localStorage.getItem('tasks')) || []; } catch(e) { return []; }
        }"""
new_load = """        let tasks = [];
        async function loadTasks() {
            try {
                const res = await fetch('/api/tasks');
                tasks = await res.json();
            } catch(e) { tasks = []; }
            render();
        }"""
html = html.replace(old_load, new_load)

# Replace save function
old_save = """        function save() {
            const d = JSON.stringify(tasks);
            localStorage.setItem('chie_tasks', d);
            localStorage.setItem('tasks', d);
            const t = document.getElementById('saveToast');
            t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 1200);
            render();
        }"""
new_save = """        async function save() {
            try {
                await fetch('/api/tasks', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(tasks) });
            } catch(e) { console.error('Save failed:', e); }
            const t = document.getElementById('saveToast');
            t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 1200);
            render();
        }"""
html = html.replace(old_save, new_save)

# Replace init block to use async load
old_init = """        // Init
        const savedTheme = localStorage.getItem('chie_theme');
        if (savedTheme==='dark') document.body.setAttribute('data-theme','dark');
        render();"""
new_init = """        // Init
        const savedTheme = localStorage.getItem('chie_theme');
        if (savedTheme==='dark') document.body.setAttribute('data-theme','dark');
        loadTasks();"""
html = html.replace(old_init, new_init)

# Remove duplicate "let tasks = loadTasks();" if present
html = html.replace("        let tasks = loadTasks();\n", "")

with open(path, "w") as f:
    f.write(html)
print("✓ HTML updated for file-based storage")
PYEOF

# 3. Update start.sh
cat > "$APP_DIR/start.sh" << 'EOF'
#!/bin/bash
cd /Users/ritchegerona/Documents/PROJECTS/task-tracker
python3 server.py &
sleep 1
open "http://localhost:8765/task_tracker.html"
echo "✓ Chie-Task_Tracker is running!"
echo "💾 Data: tasks.json"
echo "  Press Ctrl+C to stop"
wait
EOF
chmod +x "$APP_DIR/start.sh"

# 4. Rebuild .app launcher with correct python path
PYTHON_PATH=$(which python3)
mkdir -p "$APP_DIR/Chie-Task_Tracker.app/Contents/MacOS"
cat > "$APP_DIR/Chie-Task_Tracker.app/Contents/MacOS/launcher" << LAUNCHEOF
#!/bin/bash
cd "$(dirname "$0")/../.."
$PYTHON_PATH server.py
LAUNCHEOF
chmod +x "$APP_DIR/Chie-Task_Tracker.app/Contents/MacOS/launcher"
xattr -cr "$APP_DIR/Chie-Task_Tracker.app" 2>/dev/null

echo ""
echo "✅ Chie-Task_Tracker v5.3 installed!"
echo "💾 Storage: File-based (tasks.json)"
echo "🛡️  Safe from browser cache clears"
echo "🔄 Portable across browsers/devices"
echo ""
echo "→ Run: ./start.sh or double-click Chie-Task_Tracker.app"
