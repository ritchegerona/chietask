#!/bin/bash
APP_DIR="/Users/ritchegerona/Documents/PROJECTS/task-tracker"

echo "🔧 Patching v5.1: Adding Edit Task + Progress Bars..."

# Read current HTML and inject missing features via sed-style replacement
python3 << 'PYEOF'
import re, os

path = "/Users/ritchegerona/Documents/PROJECTS/task-tracker/task_tracker.html"
with open(path, 'r') as f:
    html = f.read()

# 1. Add progress bar CSS after .task-meta styles
progress_css = """
        .progress-row { display: flex; align-items: center; gap: 8px; margin-top: 6px; }
        .progress-bar { flex: 1; height: 6px; background: var(--border); border-radius: 3px; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 3px; transition: width 0.3s ease; }
        .progress-label { font-size: 10px; color: var(--text-light); font-weight: 700; min-width: 32px; text-align: right; }
        .edit-btn { width: 28px; height: 28px; border-radius: 6px; border: none; background: none; color: var(--text-light); cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 14px; }
        .edit-btn:hover { background: var(--bg); color: var(--mint); }
        .edit-modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.3); z-index: 200; display: none; align-items: center; justify-content: center; }
        .edit-modal-overlay.open { display: flex; }
        .edit-modal { background: var(--card); border-radius: 12px; padding: 24px; width: 420px; max-width: 90vw; box-shadow: 0 10px 40px rgba(0,0,0,0.15); }
        .edit-modal h3 { font-size: 16px; margin-bottom: 16px; color: var(--text); }
        .edit-field { margin-bottom: 12px; }
        .edit-field label { display: block; font-size: 11px; color: var(--text-light); margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
        .edit-field input, .edit-field select { width: 100%; padding: 10px 12px; border: 1.5px solid var(--border); border-radius: 8px; font-size: 13px; background: var(--bg); color: var(--text); }
        .edit-field input:focus, .edit-field select:focus { outline: none; border-color: var(--mint); }
        .edit-actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 16px; }
        .edit-save { padding: 10px 24px; background: var(--mint); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; }
        .edit-save:hover { background: var(--mint-dark); }
        .edit-cancel { padding: 10px 24px; background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 8px; cursor: pointer; }
        .edit-cancel:hover { background: var(--border); }"""

html = html.replace(
    "        .save-toast {",
    progress_css + "\n        .save-toast {"
)

# 2. Replace task card template to include progress bar + edit button
old_card = """                    <div class="task-actions">
                        <button class="act-btn" onclick="deleteTask(${t.id})" title="Delete">🗑</button>
                    </div>"""

new_card = """                    <div class="task-actions">
                        <button class="edit-btn" onclick="openEdit(${t.id})" title="Edit">✏️</button>
                        <button class="act-btn" onclick="deleteTask(${t.id})" title="Delete">🗑</button>
                    </div>
                </div>
                <div class="progress-row">
                    <div class="progress-bar"><div class="progress-fill" style="width:${t.progress}%;background:${getPrioColor(t.priority)}"></div></div>
                    <span class="progress-label">${t.progress}%</span>
                    <button class="timer-btn" onclick="updateProgress(${t.id},-10)" style="padding:2px 6px;font-size:9px;">-</button>
                    <button class="timer-btn" onclick="updateProgress(${t.id},10)" style="padding:2px 6px;font-size:9px;">+</button>
                </div>"""

# Fix: the old_card ends with </div> for task-card, but we need progress OUTSIDE task-info but INSIDE task-card
# Actually let's replace more precisely
old_task_end = """                    <div class="task-actions">
                        <button class="act-btn" onclick="deleteTask(${t.id})" title="Delete">🗑</button>
                    </div>
                </div>"""

new_task_end = """                    <div class="task-actions">
                        <button class="edit-btn" onclick="openEdit(${t.id})" title="Edit">✏️</button>
                        <button class="act-btn" onclick="deleteTask(${t.id})" title="Delete">🗑</button>
                    </div>
                </div>
                <div class="progress-row">
                    <div class="progress-bar"><div class="progress-fill" style="width:${t.progress}%;background:${getPrioColor(t.priority)}"></div></div>
                    <span class="progress-label">${t.progress}%</span>
                    <button class="timer-btn" onclick="updateProgress(${t.id},-10)" style="padding:2px 6px;font-size:9px;">-</button>
                    <button class="timer-btn" onclick="updateProgress(${t.id},10)" style="padding:2px 6px;font-size:9px;">+</button>
                </div>
            </div>"""

html = html.replace(old_task_end, new_task_end)

# 3. Add edit modal HTML before save-toast
edit_modal = """
    <!-- EDIT MODAL -->
    <div class="edit-modal-overlay" id="editOverlay" onclick="if(event.target===this)closeEdit()">
        <div class="edit-modal">
            <h3>✏️ Edit Task</h3>
            <input type="hidden" id="editId">
            <div class="edit-field"><label>Task Name</label><input type="text" id="editText"></div>
            <div class="edit-field"><label>Category</label>
                <select id="editCat">
                    <option value="Meetings">Meetings</option><option value="Reports">Reports</option>
                    <option value="Emails">Emails</option><option value="Admin">Admin</option>
                    <option value="Client">Client</option><option value="Follow-up">Follow-up</option>
                </select>
            </div>
            <div class="edit-field"><label>Priority</label>
                <select id="editPrio">
                    <option value="urgent">Urgent</option><option value="high">High</option>
                    <option value="normal">Normal</option><option value="low">Low</option>
                </select>
            </div>
            <div class="edit-field"><label>Due Date</label><input type="date" id="editDue"></div>
            <div class="edit-field"><label>Progress (%)</label><input type="number" id="editProgress" min="0" max="100" step="10"></div>
            <div class="edit-actions">
                <button class="edit-cancel" onclick="closeEdit()">Cancel</button>
                <button class="edit-save" onclick="saveEdit()">Save Changes</button>
            </div>
        </div>
    </div>
"""
html = html.replace('    <div id="saveToast"', edit_modal + '\n    <div id="saveToast"')

# 4. Add JS functions before the render() call at bottom
edit_js = """
        // --- EDIT TASK ---
        function openEdit(id) {
            const t = tasks.find(x => x.id === id);
            if (!t) return;
            document.getElementById('editId').value = t.id;
            document.getElementById('editText').value = t.text;
            document.getElementById('editCat').value = t.category || 'Meetings';
            document.getElementById('editPrio').value = t.priority || 'normal';
            document.getElementById('editDue').value = t.dueDate || '';
            document.getElementById('editProgress').value = t.progress || 0;
            document.getElementById('editOverlay').classList.add('open');
        }

        function closeEdit() { document.getElementById('editOverlay').classList.remove('open'); }

        function saveEdit() {
            const id = parseInt(document.getElementById('editId').value);
            const t = tasks.find(x => x.id === id);
            if (!t) return;
            t.text = document.getElementById('editText').value.trim() || t.text;
            t.category = document.getElementById('editCat').value;
            t.priority = document.getElementById('editPrio').value;
            t.dueDate = document.getElementById('editDue').value || null;
            t.progress = Math.max(0, Math.min(100, parseInt(document.getElementById('editProgress').value) || 0));
            if (t.progress === 100 && !t.completed) { t.completed = true; t.completedDate = new Date().toISOString(); }
            if (t.progress < 100 && t.completed) { t.completed = false; t.completedDate = null; }
            closeEdit();
            save();
        }

        // --- PROGRESS UPDATE ---
        function updateProgress(id, delta) {
            const t = tasks.find(x => x.id === id);
            if (!t || t.completed) return;
            t.progress = Math.max(0, Math.min(100, t.progress + delta));
            if (t.progress === 100) { t.completed = true; t.completedDate = new Date().toISOString(); if(activeTimerId===id) stopTimer(id); }
            save();
        }

        function getPrioColor(p) {
            return {urgent:'var(--urgent)',high:'var(--high)',normal:'var(--normal)',low:'var(--low)'}[p] || 'var(--normal)';
        }

"""

html = html.replace("        // Init\n", edit_js + "        // Init\n")

with open(path, 'w') as f:
    f.write(html)

print("✓ Patched successfully")
PYEOF

echo ""
echo "✅ Chie-Task_Tracker v5.1 patched!"
echo "✏️  Edit Task: Click pencil icon → modal with all fields"
echo "📊 Progress Bar: Below each task with +/- buttons"
echo "🔄 Auto-complete at 100%, auto-uncomplete below 100%"
echo ""
echo "→ Refresh your browser or relaunch from Dock!"
