cat > /Users/ritchegerona/Documents/PROJECTS/task-tracker/install_v5_4.sh << 'SCRIPT'
#!/bin/bash
APP_DIR="/Users/ritchegerona/Documents/PROJECTS/task-tracker"

echo "📁 Upgrading to v5.4: Organized Storage Folder..."

# 1. Create storage folder
mkdir -p "$APP_DIR/storage"

# 2. Move existing tasks.json if present
if [ -f "$APP_DIR/tasks.json" ]; then
    mv "$APP_DIR/tasks.json" "$APP_DIR/storage/tasks.json"
    echo "✓ Migrated tasks.json → storage/"
fi

# 3. Update server.py to use storage/ folder
cat > "$APP_DIR/server.py" << 'PYEOF'
import http.server, socketserver, os, webbrowser, threading, json

PORT = 8765
DIR = os.path.dirname(os.path.abspath(__file__))
STORAGE_DIR = os.path.join(DIR, "storage")
TASKS_FILE = os.path.join(STORAGE_DIR, "tasks.json")
os.chdir(DIR)

# Ensure storage folder exists
os.makedirs(STORAGE_DIR, exist_ok=True)

def load_tasks():
    try:
        with open(TASKS_FILE, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_tasks(data):
    with open(TASKS_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/tasks":
            tasks = load_tasks()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(tasks).encode())
            return
        super().do_GET()

    def do_POST(self):
        if self.path == "/api/tasks":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            try:
                data = json.loads(body)
                save_tasks(data)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"ok":true}')
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode())
            return
        self.send_response(404)
        self.end_headers()

    def log_message(self, format, *args):
        pass

if not os.path.exists(TASKS_FILE):
    save_tasks([])
    print(f"✓ Created {TASKS_FILE}")

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    url = f"http://localhost:{PORT}/task_tracker.html"
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    print(f"✓ Chie-Task_Tracker v5.4 running at {url}")
    print(f"💾 Storage: {TASKS_FILE}")
    print("  Press Ctrl+C to stop")
    httpd.serve_forever()
PYEOF

# 4. Update start.sh
cat > "$APP_DIR/start.sh" << 'EOF'
#!/bin/bash
cd /Users/ritchegerona/Documents/PROJECTS/task-tracker
python3 server.py &
sleep 1
open "http://localhost:8765/task_tracker.html"
echo "✓ Chie-Task_Tracker is running!"
echo "💾 Data: storage/tasks.json"
echo "  Press Ctrl+C to stop"
wait
EOF
chmod +x "$APP_DIR/start.sh"

# 5. Rebuild .app launcher
PYTHON_PATH=$(which python3)
mkdir -p "$APP_DIR/Chie-Task_Tracker.app/Contents/MacOS"
cat > "$APP_DIR/Chie-Task_Tracker.app/Contents/MacOS/launcher" << LAUNCHEOF
#!/bin/bash
cd "$(dirname "$0")/../.."
$PYTHON_PATH server.py
LAUNCHEOF
chmod +x "$APP_DIR/Chie-Task_Tracker.app/Contents/MacOS/launcher"
xattr -cr "$APP_DIR/Chie-Task_Tracker.app" 2>/dev/null

echo ""
echo "✅ Chie-Task_Tracker v5.4 installed!"
echo "📁 Project Structure:"
echo "   task-tracker/"
echo "   ├── server.py"
echo "   ├── task_tracker.html"
echo "   ├── start.sh"
echo "   ├── Chie-Task_Tracker.app/"
echo "   └── storage/"
echo "       └── tasks.json  ← Your data lives here"
echo ""
echo "→ Run: ./start.sh or double-click Chie-Task_Tracker.app"
SCRIPT

chmod +x /Users/ritchegerona/Documents/PROJECTS/task-tracker/install_v5_4.sh && \
/Users/ritchegerona/Documents/PROJECTS/task-tracker/install_v5_4.sh