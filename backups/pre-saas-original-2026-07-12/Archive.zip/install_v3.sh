#!/bin/bash
APP_DIR="/Users/ritchegerona/Documents/PROJECTS/task-tracker"
APP_NAME="TaskTracker.app"
ICON_COLOR="#7bcba3" # Greener mint

echo "🌿 Updating Task Tracker to v3 (Deadlines + Greener Mint)..."

# 1. Update HTML with Deadlines Card & Greener Mint
cat > "$APP_DIR/task_tracker.html" << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Tracker</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            max-width: 950px; 
            margin: 40px auto; 
            padding: 20px; 
            background: #faf9f7;
            min-height: 100vh;
            color: #5a5a5a;
        }
        .container {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.04);
        }
        h1 { color: #6b5e54; margin-bottom: 25px; font-size: 26px; font-weight: 600; }
        
        /* Dashboard Grid */
        .dashboard {
            display: grid;
            grid-template-columns: 1.8fr 1.2fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        .left-col { display: flex; flex-direction: column; gap: 15px; }
        .right-col { display: flex; flex-direction: column; gap: 15px; }

        /* Stats */
        .stats { display: flex; gap: 12px; }
        .stat-box {
            flex: 1; background: #f8f6f4; padding: 15px; border-radius: 10px; 
            text-align: center; border: 1px solid #f0ede9;
        }
        .stat-number { font-size: 22px; font-weight: 700; color: #7bcba3; } /* Greener Mint */
        .stat-label { font-size: 10px; color: #9a9a9a; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.5px; }

        /* Progress Bar */
        .overall-progress { height: 6px; background: #f0ede9; border-radius: 3px; overflow: hidden; }
        .overall-progress-fill { height: 100%; background: #7bcba3; transition: width 0.3s ease; }

        /* Deadlines Card (NEW) */
        .deadlines-card {
            background: #f8f6f4; border: 1px solid #f0ede9; border-radius: 10px; padding: 18px; flex: 1;
        }
        .card-title { font-size: 14px; font-weight: 700; color: #6b5e54; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
        .deadline-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 10px 12px; background: white; border-radius: 8px; margin-bottom: 8px;
            border-left: 3px solid #e0e0e0; font-size: 13px;
        }
        .deadline-item.overdue { border-left-color: #e895a8; background: #fffafa; }
        .deadline-item.today { border-left-color: #f4d4a7; background: #fffcf5; }
        .deadline-item.tomorrow { border-left-color: #7bcba3; }
        .deadline-meta { font-size: 11px; color: #9a9a9a; }
        .snooze-btn {
            background: none; border: 1px solid #e8e5e1; color: #7c6f64; 
            font-size: 10px; padding: 3px 8px; border-radius: 4px; cursor: pointer; margin-left: 6px;
        }
        .snooze-btn:hover { background: #7bcba3; color: white; border-color: #7bcba3; }
        .no-deadlines { color: #c0c0c0; font-style: italic; text-align: center; padding: 20px; font-size: 13px; }

        /* Calendar & Summary */
        .calendar-widget, .summary-widget { background: #f8f6f4; padding: 15px; border-radius: 10px; border: 1px solid #f0ede9; }
        .calendar-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .calendar-title { font-size: 13px; font-weight: 700; color: #6b5e54; }
        .calendar-nav { background: none; border: none; color: #7bcba3; cursor: pointer; font-size: 16px; padding: 2px 6px; }
        .calendar-nav:hover { background: #e8f5e9; border-radius: 4px; }
        .calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 3px; text-align: center; }
        .calendar-day-header { font-size: 9px; color: #9a9a9a; padding: 4px; font-weight: 600; }
        .calendar-day { font-size: 11px; padding: 5px; border-radius: 6px; cursor: pointer; position: relative; }
        .calendar-day:hover { background: #e8f5e9; }
        .calendar-day.today { background: #7bcba3; color: white; font-weight: 700; }
        .calendar-day.has-tasks::after { content:''; position:absolute; bottom:2px; left:50%; transform:translateX(-50%); width:4px; height:4px; background:#f4a7b9; border-radius:50%; }
        .calendar-day.other-month { color: #d0d0d0; }

        .summary-title { font-size: 12px; font-weight: 700; color: #6b5e54; margin-bottom: 8px; }
        .summary-item { display: flex; justify-content: space-between; padding: 5px 0; font-size: 11px; border-bottom: 1px solid #f0ede9; }
        .summary-item:last-child { border-bottom: none; }
        .summary-label { color: #9a9a9a; }
        .summary-value { color: #5a5a5a; font-weight: 700; }

        /* Input & Tasks */
        .input-section { display: flex; gap: 10px; margin-bottom: 25px; }
        input[type="text"] { 
            flex: 1; padding: 12px 15px; border: 1.5px solid #e8e5e1; border-radius: 10px; 
            font-size: 14px; background: #faf9f7; transition: all 0.2s; 
        }
        input[type="text"]:focus { outline: none; border-color: #7bcba3; background: white; }
        input[type="date"] {
            padding: 10px 12px; border: 1.5px solid #e8e5e1; border-radius: 10px; 
            font-size: 13px; background: #faf9f7; color: #5a5a5a; font-family: inherit;
        }
        input[type="date"]:focus { outline: none; border-color: #7bcba3; background: white; }
        button { 
            padding: 12px 24px; background: #7bcba3; color: white; border: none; 
            border-radius: 10px; cursor: pointer; font-weight: 600; transition: all 0.2s; 
        }
        button:hover { background: #6ab892; transform: translateY(-1px); box-shadow: 0 2px 8px rgba(123,203,163,0.3); }
        
        .section { margin-bottom: 25px; }
        h2 { color: #6b5e54; margin-bottom: 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px; }
        .task-list { background: #faf9f7; padding: 5px; border-radius: 10px; }
        .task-item { 
            display: flex; flex-direction: column; padding: 14px; background: white; 
            margin-bottom: 8px; border-radius: 8px; border: 1px solid #f0ede9; transition: all 0.2s; 
        }
        .task-item:hover { box-shadow: 0 2px 12px rgba(0,0,0,0.04); border-color: #7bcba3; }
        .task-header { display: flex; align-items: center; margin-bottom: 8px; }
        .task-item input[type="checkbox"] { width: 18px; height: 18px; margin-right: 12px; cursor: pointer; accent-color: #7bcba3; }
        .task-text { flex: 1; font-size: 14px; color: #5a5a5a; font-weight: 500; }
        .completed .task-text { text-decoration: line-through; color: #c0c0c0; }
        
        .progress-container { display: flex; align-items: center; gap: 10px; margin-top: 6px; }
        .progress-bar-task { flex: 1; height: 6px; background: #f0ede9; border-radius: 3px; overflow: hidden; }
        .progress-fill-task { height: 100%; border-radius: 3px; transition: width 0.3s ease; }
        .progress-text { font-size: 11px; color: #9a9a9a; font-weight: 700; min-width: 35px; text-align: right; }
        
        .controls { display: flex; align-items: center; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
        .progress-btn { padding: 4px 10px; font-size: 10px; background: #f8f6f4; color: #7c6f64; border: 1px solid #e8e5e1; border-radius: 6px; cursor: pointer; }
        .progress-btn:hover { background: #7bcba3; color: white; border-color: #7bcba3; }
        .delete-btn { background: #f4a7b9; padding: 6px 12px; font-size: 10px; margin-left: auto; border-radius: 6px; border: none; color: white; cursor: pointer; }
        .delete-btn:hover { background: #e895a8; }
        .date-tag { font-size: 10px; color: #9a9a9a; margin-left: 10px; background: #f8f6f4; padding: 3px 8px; border-radius: 6px; }
        .empty { color: #c0c0c0; text-align: center; padding: 25px; font-style: italic; font-size: 13px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📋 Task Tracker</h1>
        
        <div class="dashboard">
            <!-- LEFT COLUMN: Stats + Deadlines Card -->
            <div class="left-col">
                <div>
                    <div class="stats">
                        <div class="stat-box"><div class="stat-number" id="totalTasks">0</div><div class="stat-label">Total</div></div>
                        <div class="stat-box"><div class="stat-number" id="pendingTasks">0</div><div class="stat-label">Pending</div></div>
                        <div class="stat-box"><div class="stat-number" id="completedTasks">0</div><div class="stat-label">Done</div></div>
                    </div>
                    <div style="margin-top:12px;" class="overall-progress"><div class="overall-progress-fill" id="progressBar" style="width:0%"></div></div>
                </div>
                
                <!-- DEADLINES CARD -->
                <div class="deadlines-card">
                    <div class="card-title">🔔 Upcoming Deadlines</div>
                    <div id="deadlinesList"></div>
                </div>
            </div>
            
            <!-- RIGHT COLUMN: Calendar + Summary -->
            <div class="right-col">
                <div class="calendar-widget">
                    <div class="calendar-header">
                        <button class="calendar-nav" onclick="changeMonth(-1)">‹</button>
                        <div class="calendar-title" id="calendarTitle"></div>
                        <button class="calendar-nav" onclick="changeMonth(1)">›</button>
                    </div>
                    <div class="calendar-grid" id="calendarGrid"></div>
                </div>
                <div class="summary-widget">
                    <div class="summary-title">📊 Summary</div>
                    <div class="summary-item"><span class="summary-label">Completion Rate</span><span class="summary-value" id="completionRate">0%</span></div>
                    <div class="summary-item"><span class="summary-label">Avg Progress</span><span class="summary-value" id="avgProgress">0%</span></div>
                    <div class="summary-item"><span class="summary-label">This Week</span><span class="summary-value" id="weekTasks">0</span></div>
                </div>
            </div>
        </div>

        <div class="input-section">
            <input type="text" id="taskInput" placeholder="What needs to be done?">
            <input type="date" id="dueDateInput" title="Optional due date">
            <button onclick="addTask()">Add Task</button>
        </div>

        <div class="section">
            <h2>⏳ Pending</h2>
            <div id="pendingList" class="task-list"></div>
        </div>
        <div class="section">
            <h2>✅ Completed</h2>
            <div id="completedList" class="task-list"></div>
        </div>
    </div>

    <script>
        let tasks = JSON.parse(localStorage.getItem('tasks_v3')) || [];
        let currentCalendarDate = new Date();
        
        function saveTasks() { localStorage.setItem('tasks_v3', JSON.stringify(tasks)); render(); }
        
        function addTask() {
            const text = document.getElementById('taskInput').value.trim();
            const due = document.getElementById('dueDateInput').value;
            if (text) {
                tasks.push({ id: Date.now(), text, completed: false, progress: 0, dueDate: due || null, snoozedUntil: null, completedDate: null, createdAt: new Date().toISOString() });
                document.getElementById('taskInput').value = '';
                document.getElementById('dueDateInput').value = '';
                saveTasks();
            }
        }
        
        function toggleTask(id) {
            const t = tasks.find(x => x.id === id);
            if (t) { t.completed = !t.completed; t.progress = t.completed ? 100 : t.progress; t.completedDate = t.completed ? new Date().toLocaleString() : null; saveTasks(); }
        }
        
        function updateProgress(id, val) {
            const t = tasks.find(x => x.id === id);
            if (t && !t.completed) { t.progress = Math.max(0, Math.min(100, val)); if (t.progress === 100) { t.completed = true; t.completedDate = new Date().toLocaleString(); } saveTasks(); }
        }
        
        function deleteTask(id) { tasks = tasks.filter(t => t.id !== id); saveTasks(); }
        
        function snoozeTask(id, hours) {
            const t = tasks.find(x => x.id === id);
            if (t) { t.snoozedUntil = new Date(Date.now() + hours * 3600000).toISOString(); saveTasks(); }
        }
        
        function getProgressColor(p) { return p < 25 ? '#f4a7b9' : p < 50 ? '#f4d4a7' : p < 75 ? '#7bcba3' : '#89c4e8'; }
        
        function changeMonth(d) { currentCalendarDate.setMonth(currentCalendarDate.getMonth() + d); renderCalendar(); }
        
        function renderCalendar() {
            const y = currentCalendarDate.getFullYear(), m = currentCalendarDate.getMonth();
            const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
            document.getElementById('calendarTitle').textContent = `${months[m]} ${y}`;
            const firstDay = new Date(y, m, 1).getDay(), daysInMonth = new Date(y, m+1, 0).getDate(), today = new Date();
            const daysWithTasks = new Set();
            tasks.forEach(t => { const d = new Date(t.createdAt); if (d.getFullYear()===y && d.getMonth()===m) daysWithTasks.add(d.getDate()); });
            let html = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => `<div class="calendar-day-header">${d}</div>`).join('');
            for (let i=0; i<firstDay; i++) html += '<div class="calendar-day other-month"></div>';
            for (let d=1; d<=daysInMonth; d++) {
                const isToday = today.getDate()===d && today.getMonth()===m && today.getFullYear()===y;
                let cls = 'calendar-day'; if (isToday) cls += ' today'; if (daysWithTasks.has(d)) cls += ' has-tasks';
                html += `<div class="${cls}">${d}</div>`;
            }
            document.getElementById('calendarGrid').innerHTML = html;
        }
        
        function renderDeadlines() {
            const now = new Date(); const todayStr = now.toISOString().slice(0,10);
            const tomorrow = new Date(now); tomorrow.setDate(tomorrow.getDate()+1); const tomorrowStr = tomorrow.toISOString().slice(0,10);
            const pending = tasks.filter(t => !t.completed && t.dueDate);
            
            // Filter out snoozed
            const visible = pending.filter(t => !t.snoozedUntil || new Date(t.snoozedUntil) <= now);
            
            if (!visible.length) { document.getElementById('deadlinesList').innerHTML = '<div class="no-deadlines">No upcoming deadlines 🎉</div>'; return; }
            
            // Sort: overdue first, then today, then future
            visible.sort((a,b) => a.dueDate.localeCompare(b.dueDate));
            
            document.getElementById('deadlinesList').innerHTML = visible.slice(0, 6).map(t => {
                let cls = '', label = '';
                if (t.dueDate < todayStr) { cls = 'overdue'; label = 'Overdue'; }
                else if (t.dueDate === todayStr) { cls = 'today'; label = 'Today'; }
                else if (t.dueDate === tomorrowStr) { cls = 'tomorrow'; label = 'Tomorrow'; }
                else { label = t.dueDate; }
                return `<div class="deadline-item ${cls}">
                    <div><strong>${t.text}</strong><div class="deadline-meta">${label} · ${t.progress}%</div></div>
                    <div>
                        <button class="snooze-btn" onclick="snoozeTask(${t.id},1)">1h</button>
                        <button class="snooze-btn" onclick="snoozeTask(${t.id},4)">4h</button>
                        <button class="snooze-btn" onclick="snoozeTask(${t.id},24)">1d</button>
                    </div>
                </div>`;
            }).join('');
        }
        
        function updateStats() {
            const total = tasks.length, completed = tasks.filter(t=>t.completed).length, pending = total-completed;
            const pct = total>0 ? (completed/total)*100 : 0;
            const avg = total>0 ? tasks.reduce((s,t)=>s+t.progress,0)/total : 0;
            const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate()-7);
            const week = tasks.filter(t => new Date(t.createdAt) >= weekAgo).length;
            document.getElementById('totalTasks').textContent = total;
            document.getElementById('pendingTasks').textContent = pending;
            document.getElementById('completedTasks').textContent = completed;
            document.getElementById('progressBar').style.width = pct+'%';
            document.getElementById('completionRate').textContent = Math.round(pct)+'%';
            document.getElementById('avgProgress').textContent = Math.round(avg)+'%';
            document.getElementById('weekTasks').textContent = week;
        }
        
        function render() {
            updateStats(); renderCalendar(); renderDeadlines();
            const pending = tasks.filter(t=>!t.completed), completed = tasks.filter(t=>t.completed);
            document.getElementById('pendingList').innerHTML = pending.length ? pending.map(t => `
                <div class="task-item">
                    <div class="task-header">
                        <input type="checkbox" onchange="toggleTask(${t.id})">
                        <span class="task-text">${t.text}</span>
                        ${t.dueDate ? `<span class="date-tag">📅 ${t.dueDate}</span>` : ''}
                    </div>
                    <div class="progress-container">
                        <div class="progress-bar-task"><div class="progress-fill-task" style="width:${t.progress}%;background:${getProgressColor(t.progress)}"></div></div>
                        <span class="progress-text">${t.progress}%</span>
                    </div>
                    <div class="controls">
                        <button class="progress-btn" onclick="updateProgress(${t.id},${Math.max(0,t.progress-10)})">-10%</button>
                        <button class="progress-btn" onclick="updateProgress(${t.id},${Math.min(100,t.progress+10)})">+10%</button>
                        <button class="progress-btn" onclick="updateProgress(${t.id},25)">25%</button>
                        <button class="progress-btn" onclick="updateProgress(${t.id},50)">50%</button>
                        <button class="progress-btn" onclick="updateProgress(${t.id},75)">75%</button>
                        <button class="delete-btn" onclick="deleteTask(${t.id})">Delete</button>
                    </div>
                </div>`).join('') : '<div class="empty">No pending tasks 🎉</div>';
            document.getElementById('completedList').innerHTML = completed.length ? completed.map(t => `
                <div class="task-item completed">
                    <div class="task-header">
                        <input type="checkbox" checked onchange="toggleTask(${t.id})">
                        <span class="task-text">${t.text}</span>
                        <span class="date-tag">✓ ${t.completedDate}</span>
                    </div>
                    <div class="progress-container">
                        <div class="progress-bar-task"><div class="progress-fill-task" style="width:100%;background:#7bcba3"></div></div>
                        <span class="progress-text">100%</span>
                    </div>
                    <div class="controls"><button class="delete-btn" onclick="deleteTask(${t.id})">Delete</button></div>
                </div>`).join('') : '<div class="empty">No completed tasks yet</div>';
        }
        
        document.getElementById('taskInput').addEventListener('keypress', e => { if(e.key==='Enter') addTask(); });
        render();
    </script>
</body>
</html>
EOF

# 2. Generate Pastel Mint Icon (Greener)
mkdir -p /tmp/icon_gen
cat > /tmp/icon_gen/icon.svg << SVGEOF
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <rect width="512" height="512" rx="96" fill="#7bcba3"/>
  <rect x="128" y="100" width="256" height="312" rx="24" fill="white" opacity="0.95"/>
  <rect x="168" y="160" width="176" height="16" rx="8" fill="#7bcba3" opacity="0.6"/>
  <rect x="168" y="196" width="140" height="16" rx="8" fill="#7bcba3" opacity="0.4"/>
  <rect x="168" y="232" width="160" height="16" rx="8" fill="#7bcba3" opacity="0.3"/>
  <circle cx="340" cy="320" r="56" fill="#7bcba3"/>
  <polyline points="316,320 332,338 364,302" fill="none" stroke="white" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
SVGEOF

# Convert SVG to PNG at multiple sizes for macOS icns
for size in 512 256 128 64 32 16; do
    sips -s format png --resampleWidth $size /tmp/icon_gen/icon.svg --out /tmp/icon_gen/icon_${size}.png 2>/dev/null || \
    python3 -c "
import subprocess, sys
try:
    from PIL import Image
    img = Image.open('/tmp/icon_gen/icon.svg')
    img = img.resize(($size,$size))
    img.save('/tmp/icon_gen/icon_${size}.png')
except: pass
" 2>/dev/null
done

# Create .app bundle
mkdir -p "$APP_DIR/$APP_NAME/Contents/MacOS"
mkdir -p "$APP_DIR/$APP_NAME/Contents/Resources"

cat > "$APP_DIR/$APP_NAME/Contents/MacOS/launcher" << LAUNCHEOF
#!/bin/bash
open "$APP_DIR/task_tracker.html"
LAUNCHEOF
chmod +x "$APP_DIR/$APP_NAME/Contents/MacOS/launcher"

cat > "$APP_DIR/$APP_NAME/Contents/Info.plist" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key><string>launcher</string>
    <key>CFBundleIconFile</key><string>AppIcon</string>
    <key>CFBundleName</key><string>Task Tracker</string>
    <key>CFBundleIdentifier</key><string>com.pastel.tasktracker</string>
    <key>CFBundleVersion</key><string>3.0</string>
</dict>
</plist>
PLISTEOF

# Build icns
if [ -f /tmp/icon_gen/icon_512.png ]; then
    mkdir -p /tmp/AppIcon.iconset
    cp /tmp/icon_gen/icon_512.png /tmp/AppIcon.iconset/icon_512x512.png
    cp /tmp/icon_gen/icon_256.png /tmp/AppIcon.iconset/icon_256x256.png
    cp /tmp/icon_gen/icon_128.png /tmp/AppIcon.iconset/icon_128x128.png
    cp /tmp/icon_gen/icon_32.png /tmp/AppIcon.iconset/icon_32x32.png
    cp /tmp/icon_gen/icon_16.png /tmp/AppIcon.iconset/icon_16x16.png
    iconutil -c icns /tmp/AppIcon.iconset -o "$APP_DIR/$APP_NAME/Contents/Resources/AppIcon.icns" 2>/dev/null
    rm -rf /tmp/AppIcon.iconset
    echo "✓ Custom mint icon applied"
else
    echo "⚠ Icon generation fallback - using default"
fi

rm -rf /tmp/icon_gen

echo ""
echo "✅ Task Tracker v3 installed!"
echo "📍 Location: $APP_DIR/$APP_NAME"
echo "🎨 Theme: Pastel Mint (#7bcba3) + Deadlines Card"
echo ""
echo "→ Drag '$APP_NAME' to your Dock!"
